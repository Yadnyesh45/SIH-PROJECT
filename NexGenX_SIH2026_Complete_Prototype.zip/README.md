# NexGenX SIH 2026 Prototype
PS ID: SIH26043 | Theme: Smart Education | Team: NexGenX
Organization: Government of Jharkhand, Department of Higher & Technical Education

Run: Open folder in VS Code → install Live Server → right-click index.html → Open with Live Server.

Demo: Home → Citizen → Submit Problem → AI Analysis → University → Industry → Government.

The AI is a local JavaScript prototype simulation. Firebase, Flask and Gemini are intentionally left for the next integration phase. Government figures 2,480 / 1,120 / 310 / 185 are labelled illustrative/projected and should not be presented as verified statistics.
